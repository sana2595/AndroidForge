package ir.almas.aggregate

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.Locale
import kotlin.coroutines.resume

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlmasAggregateApp(this) }
    }
}

data class ScanResult(val username: String, val fileName: String, val status: String)

private class UsernameStore(context: Context) {
    private val prefs = context.getSharedPreferences("almas_usernames", Context.MODE_PRIVATE)

    fun all(): List<String> = prefs.getStringSet("items", emptySet())
        .orEmpty()
        .map(::normalizeUsername)
        .filter { it.isNotBlank() }
        .distinct()
        .sorted()

    fun add(value: String) {
        val v = normalizeUsername(value)
        if (v.isBlank()) return
        prefs.edit().putStringSet("items", (all() + v).toSet()).apply()
    }

    fun remove(value: String) {
        prefs.edit().putStringSet("items", all().filter { it != value }.toSet()).apply()
    }
}

private fun normalizeUsername(value: String): String = value
    .lowercase(Locale.US)
    .replace("@", "")
    .replace(Regex("[^a-z0-9_.]"), "")

private fun safeFolderName(value: String): String = value
    .replace(Regex("[^A-Za-z0-9_.@-]"), "_")
    .take(80)
    .ifBlank { "unknown" }

private fun safeFileName(value: String): String = value
    .replace(Regex("[^A-Za-z0-9_.-]"), "_")
    .take(100)

private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
    .digest(bytes)
    .joinToString("") { "%02x".format(it) }

private const val PREFS = "almas_settings"
private const val OUTPUT_URI = "output_uri"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlmasAggregateApp(context: Context) {
    val store = remember { UsernameStore(context) }
    var usernames by remember { mutableStateOf(store.all()) }
    var newUsername by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("آماده برای اسکن") }
    var running by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(listOf<ScanResult>()) }
    var scanJob by remember { mutableStateOf<Job?>(null) }
    var outputUri by remember {
        mutableStateOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(OUTPUT_URI, null))
    }
    val scope = rememberCoroutineScope()

    val outputPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) { }
            outputUri = uri.toString()
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(OUTPUT_URI, outputUri).apply()
            status = "پوشه خروجی انتخاب شد"
        }
    }

    val sourcePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null && !running && usernames.isNotEmpty()) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }

            val savedOutput = outputUri
            if (savedOutput.isNullOrBlank()) {
                status = "ابتدا پوشه خروجی را انتخاب کنید"
                return@rememberLauncherForActivityResult
            }

            running = true
            results = emptyList()
            scanJob = scope.launch {
                try {
                    scanFolder(
                        context = context,
                        sourceUri = uri,
                        outputUri = Uri.parse(savedOutput),
                        usernames = usernames,
                        onProgress = { status = it },
                        onResult = { result -> results = results + result }
                    )
                } catch (_: kotlinx.coroutines.CancellationException) {
                    status = "اسکن توسط کاربر متوقف شد"
                } catch (e: Exception) {
                    status = "خطا: ${e.message ?: "خطای نامشخص"}"
                } finally {
                    running = false
                    scanJob = null
                }
            }
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("سامانه الماس")
                        Text("اسکن تجمیعی و دسته‌بندی عکس‌ها", style = MaterialTheme.typography.labelMedium)
                    }
                })
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.Top
            ) {
                Text("نام‌های کاربری افراد", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = newUsername,
                        onValueChange = { newUsername = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("مثلاً username") }
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { store.add(newUsername); usernames = store.all(); newUsername = "" },
                        enabled = newUsername.isNotBlank() && !running
                    ) { Text("افزودن") }
                }

                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.heightIn(max = 150.dp)) {
                    items(usernames) { username ->
                        ListItem(
                            headlineContent = { Text(username, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End) },
                            trailingContent = {
                                TextButton(onClick = { store.remove(username); usernames = store.all() }, enabled = !running) { Text("حذف") }
                            }
                        )
                        HorizontalDivider()
                    }
                }

                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { outputPicker.launch(null) },
                    enabled = !running,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (outputUri == null) "۱. انتخاب پوشه خروجی" else "۱. تغییر پوشه خروجی") }

                Button(
                    onClick = { sourcePicker.launch(null) },
                    enabled = usernames.isNotEmpty() && !running && outputUri != null,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("۲. انتخاب پوشه تصاویر و شروع اسکن") }

                if (running) {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { scanJob?.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("توقف اسکن") }
                }

                Spacer(Modifier.height(6.dp))
                Text(status, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
                Spacer(Modifier.height(6.dp))
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "نام کاربری را بدون @ وارد کنید. برنامه ابتدا بخش بالای تصویر را بررسی می‌کند و اگر تطبیق پیدا نشد، کل تصویر را OCR می‌کند. هر تصویر در پوشه نام کاربری متناظر کپی می‌شود و تکراری‌ها با SHA-256 دوباره ذخیره نمی‌شوند.",
                        modifier = Modifier.padding(12.dp), textAlign = TextAlign.End, style = MaterialTheme.typography.bodySmall
                    )
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.fillMaxSize()) {
                    items(results) { result ->
                        ListItem(
                            headlineContent = { Text(result.username) },
                            supportingContent = { Text("${result.fileName} — ${result.status}") }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

private suspend fun scanFolder(
    context: Context,
    sourceUri: Uri,
    outputUri: Uri,
    usernames: List<String>,
    onProgress: (String) -> Unit,
    onResult: (ScanResult) -> Unit
) {
    val root = DocumentFile.fromTreeUri(context, sourceUri) ?: error("پوشه تصاویر قابل دسترسی نیست")
    val outputRoot = DocumentFile.fromTreeUri(context, outputUri) ?: error("پوشه خروجی قابل دسترسی نیست")
    val images = mutableListOf<DocumentFile>()
    collectImages(root, images)
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    try {
        images.forEachIndexed { index, documentFile ->
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            onProgress("در حال اسکن تصویر ${index + 1} از ${images.size}")
            val matches = detectMatches(context, documentFile.uri, usernames, recognizer)
            if (matches.isEmpty()) return@forEachIndexed

            val bytes = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(documentFile.uri)?.use { it.readBytes() }
            } ?: return@forEachIndexed
            val hash = sha256(bytes)
            val originalName = documentFile.name ?: "image.jpg"

            matches.forEach { username ->
                kotlinx.coroutines.currentCoroutineContext().ensureActive()
                val folderName = safeFolderName(username)
                val folder = outputRoot.findFile(folderName)?.takeIf { it.isDirectory }
                    ?: outputRoot.createDirectory(folderName)
                if (folder == null) {
                    onResult(ScanResult(username, originalName, "خطا در ساخت پوشه"))
                    return@forEach
                }

                val extension = originalName.substringAfterLast('.', "jpg").lowercase(Locale.US).take(5)
                val targetName = "${hash}_${safeFileName(originalName)}"
                val existing = folder.findFile(targetName)
                if (existing != null) {
                    onResult(ScanResult(username, originalName, "تکراری؛ ذخیره نشد"))
                } else {
                    val target = folder.createFile("image/$extension", targetName)
                    if (target == null) {
                        onResult(ScanResult(username, originalName, "خطا در ایجاد فایل"))
                    } else {
                        withContext(Dispatchers.IO) {
                            context.contentResolver.openOutputStream(target.uri)?.use { it.write(bytes) }
                                ?: error("خروجی فایل باز نشد")
                        }
                        onResult(ScanResult(username, originalName, "ذخیره شد"))
                    }
                }
            }
        }
        onProgress("اسکن تمام شد؛ ${images.size} تصویر بررسی شد.")
    } finally {
        recognizer.close()
    }
}

private fun collectImages(node: DocumentFile, output: MutableList<DocumentFile>) {
    node.listFiles().forEach { file ->
        if (file.isDirectory) collectImages(file, output)
        else if (file.isFile && file.type?.startsWith("image/") == true) output += file
    }
}

private suspend fun detectMatches(
    context: Context,
    uri: Uri,
    usernames: List<String>,
    recognizer: TextRecognizer
): List<String> {
    val bitmap = withContext(Dispatchers.IO) { decodeScaledBitmap(context, uri) } ?: return emptyList()
    return try {
        val topLeftText = ocr(recognizer, cropTopLeft(bitmap))
        val topMatches = findMatches(topLeftText, usernames)
        if (topMatches.isNotEmpty()) return topMatches
        val fullText = ocr(recognizer, bitmap)
        findMatches(fullText, usernames)
    } finally {
        bitmap.recycle()
    }
}

private fun findMatches(text: String, usernames: List<String>): List<String> {
    val normalizedText = normalizeUsername(text)
    return usernames.filter { candidate ->
        val normalized = normalizeUsername(candidate)
        normalized.isNotBlank() && normalizedText.contains(normalized)
    }
}

private fun decodeScaledBitmap(context: Context, uri: Uri): Bitmap? {
    return context.contentResolver.openInputStream(uri)?.use { input ->
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }
}

private fun cropTopLeft(bitmap: Bitmap): Bitmap {
    val width = bitmap.width.coerceAtLeast(1)
    val height = bitmap.height.coerceAtLeast(1)
    val cropWidth = (width * 0.65f).toInt().coerceIn(1, width)
    val cropHeight = (height * 0.48f).toInt().coerceIn(1, height)
    return Bitmap.createBitmap(bitmap, 0, 0, cropWidth, cropHeight)
}

private suspend fun ocr(recognizer: TextRecognizer, bitmap: Bitmap): String =
    suspendCancellableCoroutine { continuation ->
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result -> continuation.resume(result.text) }
            .addOnFailureListener { continuation.resume("") }
    }
