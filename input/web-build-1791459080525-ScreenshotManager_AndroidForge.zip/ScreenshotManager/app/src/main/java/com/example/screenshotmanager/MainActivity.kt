package com.example.screenshotmanager

import android.content.ContentResolver
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern

class MainActivity : ComponentActivity() {
    private val executor = Executors.newFixedThreadPool(3)
    private val rows = mutableListOf<Row>()
    private lateinit var status: TextView
    private lateinit var list: LinearLayout

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
        }
        rows.clear(); list.removeAllViews()
        uris.forEach { rows.add(Row(it)) }
        status.text = "${rows.size} تصویر انتخاب شد."
        scanAll()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24); gravity = Gravity.TOP }
        val title = TextView(this).apply { text = "مدیریت اسکرین‌شات"; textSize = 24f; gravity = Gravity.CENTER; setPadding(0,0,0,24) }
        root.addView(title)
        val choose = Button(this).apply { text = "انتخاب تصاویر"; setOnClickListener { picker.launch(arrayOf("image/*")) } }
        root.addView(choose)
        status = TextView(this).apply { text = "هنوز تصویری انتخاب نشده است."; setPadding(0,16,0,16) }
        root.addView(status)
        val rename = Button(this).apply { text = "تغییرنام گروهی"; setOnClickListener { renameAll() } }
        root.addView(rename)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun scanAll() {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rows.forEachIndexed { index, row ->
            executor.execute {
                try {
                    val image = InputImage.fromFilePath(this, row.uri)
                    recognizer.process(image).addOnSuccessListener { result ->
                        row.username = detectUsername(result.text)
                        runOnUiThread { refreshRow(index) }
                    }.addOnFailureListener { runOnUiThread { refreshRow(index) } }
                } catch (_: Exception) { runOnUiThread { refreshRow(index) } }
            }
        }
    }

    private fun detectUsername(text: String): String? {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val patterns = listOf(
            Pattern.compile("(?<![A-Za-z0-9_])@([A-Za-z0-9._]{2,64})"),
            Pattern.compile("(?:instagram|telegram|user(?:name)?)[\\s:@_-]*([A-Za-z0-9._]{2,64})", Pattern.CASE_INSENSITIVE)
        )
        for (line in lines) for (p in patterns) p.matcher(line).takeIf { it.find() }?.let { return it.group(1) }
        return null
    }

    private fun refreshRow(index: Int) {
        val row = rows[index]
        val label = if (row.username == null) "نام کاربری پیدا نشد" else "@${row.username}"
        if (index < list.childCount) (list.getChildAt(index) as TextView).text = "${index+1}. $label"
        else { list.addView(TextView(this).apply { text = "${index+1}. $label"; textSize=16f; setPadding(0,10,0,10) }) }
        val done = rows.count { it.username != null }
        status.text = "تشخیص: $done از ${rows.size}"
    }

    private fun renameAll() {
        val counts = mutableMapOf<String,Int>()
        var renamed = 0
        rows.forEach { row ->
            val u = row.username ?: return@forEach
            val n = (counts[u] ?: 0) + 1; counts[u] = n
            val base = sanitize(u) + if (n > 1) "_${n.toString().padStart(3,'0')}" else ""
            val ext = extension(row.uri)
            try {
                val newUri = DocumentsContract.renameDocument(contentResolver, row.uri, "$base$ext")
                if (newUri != null) { row.uri = newUri; renamed++ }
            } catch (_: Exception) { }
        }
        status.text = "تلاش برای تغییرنام ${renamed} فایل انجام شد. اگر فایل‌منیجر اجازه تغییرنام ندهد، تصاویر را داخل پوشه‌ای که توسط برنامه ساخته شده وارد کنید."
    }

    private fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_').ifBlank { "username" }
    private fun extension(uri: Uri): String { val name = uri.lastPathSegment ?: return ".jpg"; val i = name.lastIndexOf('.'); return if (i >= 0) name.substring(i) else ".jpg" }
    data class Row(var uri: Uri, var username: String? = null)
}
